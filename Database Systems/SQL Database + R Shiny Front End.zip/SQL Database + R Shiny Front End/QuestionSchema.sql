DROP DATABASE IF EXISTS RLO;
CREATE DATABASE RLO;
USE RLO;

DROP TABLE IF EXISTS Response;
DROP TABLE IF EXISTS Question;
DROP TABLE IF EXISTS Student;
DROP TABLE IF EXISTS Theme;

CREATE TABLE Student (
	s_id				INT NOT NULL AUTO_INCREMENT,
	s_year 				YEAR CHECK (s_year >= 2022 AND s_year <= 2024),
	hall				VARCHAR(40),
	PRIMARY KEY (s_id)
);

CREATE TABLE Question (
	q_id				INT NOT NULL,
	q_text				VARCHAR(400),
	PRIMARY KEY (q_id)
);

CREATE TABLE Theme (
	t_id				INT NOT NULL,
	theme				VARCHAR(40),
	PRIMARY KEY (t_id)
);

CREATE TABLE Response (
	s_id 				INT NOT NULL,
	q_id				INT NOT NULL,
	response			VARCHAR(1600),
	theme1				VARCHAR(40),
	theme2				VARCHAR(40),
	theme3				VARCHAR(40),
	PRIMARY KEY (s_id, q_id),
	FOREIGN KEY (s_id) REFERENCES Student (s_id) ON DELETE CASCADE,
	FOREIGN KEY (q_id) REFERENCES Question (q_id) ON DELETE CASCADE
);

INSERT INTO Theme VALUES (0, 'Cake race');
INSERT INTO Theme VALUES (1, 'Flickerball');
INSERT INTO Theme VALUES (2, 'Discounts');
INSERT INTO Theme VALUES (3, 'Christmas in Davidson');
INSERT INTO Theme VALUES (4, 'Conflict resolution');
INSERT INTO Theme VALUES (5, 'Counseling');
INSERT INTO Theme VALUES (6, 'Writing center');
INSERT INTO Theme VALUES (7, 'Office hours');
INSERT INTO Theme VALUES (8, 'Webtree');
INSERT INTO Theme VALUES (9, 'RLO');
INSERT INTO Theme VALUES (10, 'Hall counselors');
INSERT INTO Theme VALUES (11, 'Communication');
INSERT INTO Theme VALUES (12, 'Resources');
INSERT INTO Theme VALUES (13, 'Time management');
INSERT INTO Theme VALUES (14, 'Campus community');
INSERT INTO Theme VALUES (15, 'Friends');
INSERT INTO Theme VALUES (16, 'Activities');
INSERT INTO Theme VALUES (17, 'Schoolwork');
INSERT INTO Theme VALUES (18, 'Good');
INSERT INTO Theme VALUES (19, 'Unnecessary');
INSERT INTO Theme VALUES (20, 'Bad');

# Sample data intake from MySQL database
# Calvin Spencer

# Dependencies ----
library(dplyr)
library(RMariaDB)

# Connect to MuySQL with RMariaDB ----
con <- DBI::dbConnect(drv = RMariaDB::MariaDB(),
                      dbname = "RLO",
                      host = "localhost",
                      username = "root",
                      password = "123456",
                      port = 3306)
# Read tables
df_question <- DBI::dbReadTable(con, 'Question')
df_response <- DBI::dbReadTable(con, 'Response')
df_student <- DBI::dbReadTable(con, 'Student')
df_theme <- DBI::dbReadTable(con, 'Theme')

# Load data into reactive container
r <- reactiveValues()
r$df_question <- df_question
r$df_response <- df_response
r$df_student <- df_student
r$df_theme <- df_theme

write.csv(df_question, "df_question.csv")
write.csv(df_response, "df_response.csv")
write.csv(df_student, "df_student.csv")
write.csv(df_theme, "df_theme.csv")
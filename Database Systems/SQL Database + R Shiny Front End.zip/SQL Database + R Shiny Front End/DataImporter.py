import mysql.connector
import os
import glob
import datetime
import heapq
import pandas as pd
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
nltk.download('all')
from collections import Counter
import string

# This converts the date obtained from the csv files into a SQL date string.
def convertDate(date):
    date = str(date)
    year = date[0:4]
    month = date[4:6]
    day = date[6:8]

    return year + "-" + month + "-" + day

# this helper function iterates through an Id and copies all but the "-" character to a new Id. It 
# returns the new id as an int
def convertId(Id):
    newId = ""
    for i in range(len(Id)):
        if Id[i] != "-":
            newId += Id[i]
    return

# this helper function identifies themes in a response in order of decreasing specificity and
# returns an array containing strings of the ids of the three most specific themes discussed 
# in the response and None wherever a theme could not be assigned
def themeIdentifier(response):
    translator = str.maketrans('', '', string.punctuation)
    lowerResp = response.translate(translator).lower()
    tokens = word_tokenize(lowerResp)
    tokens_without_sw = [word for word in tokens if not word in stopwords.words()]
    themes = ""
    
    if ("cake" in tokens_without_sw) and ("race" in tokens_without_sw):
        themes += "0 "
    if ("flickerball" in tokens_without_sw):
        themes += "1 "
    if ("discounts" in tokens_without_sw):
        themes += "2 "
    if ("christmas" in tokens_without_sw) and ("davidson" in tokens_without_sw):
        themes += "3 "
    if ("conflict" in tokens_without_sw) and ("resolution" in tokens_without_sw):
        themes += "4 "
    if ("counseling" in tokens_without_sw):
        themes += "5 "
    if ("writing" in tokens_without_sw) and ("center" in tokens_without_sw):
        themes += "6 "
    if ("office" in tokens_without_sw) and ("hours" in tokens_without_sw):
        themes += "7 "
    if ("webtree" in tokens_without_sw):
        themes += "8 "
    if ("rlo" in tokens_without_sw):
        themes += "9 "
    if (("hall" in tokens_without_sw) and ("counselors" in tokens_without_sw)) or ("ras" in tokens_without_sw):
        themes += "10 "
    if ("communication" in tokens_without_sw):
        themes += "11 "
    if ("help" in tokens_without_sw) or ("resource" in tokens_without_sw) or ("resources" in tokens_without_sw):
        themes += "12 "
    if ("time" in tokens_without_sw):
        themes += "13 "
    if ("campus" in tokens_without_sw) or ("community" in tokens_without_sw) or ("traditions" in tokens_without_sw):
        themes += "14 "
    if ("friends" in tokens_without_sw) or ("fun" in tokens_without_sw) or ("social" in tokens_without_sw):
        themes += "15 "
    if ("clubs" in tokens_without_sw) or ("involved" in tokens_without_sw) or ("activities" in tokens_without_sw):
        themes += "16 "
    if ("classes" in tokens_without_sw) or ("school" in tokens_without_sw) or ("work" in tokens_without_sw):
        themes += "17 "
    if ("good" in tokens_without_sw) or ("nice" in tokens_without_sw) or ("great" in tokens_without_sw) or ("helpful" in tokens_without_sw):
        themes += "18 "
    if (("didnt" in tokens_without_sw) or ("never" in tokens_without_sw) or ("wasnt" in tokens_without_sw)) and (("attend" in tokens_without_sw) or ("participate" in tokens_without_sw) or ("talk" in tokens_without_sw) or ("needed" in tokens_without_sw)):
        themes += "19 "
    if ("bad" in tokens_without_sw):
        themes += "20 "
    
    splitThemes = themes.split(" ")[:3]
    if splitThemes[-1] == "":
        splitThemes = splitThemes[:(len(splitThemes)-1)]

    finalThemes = [None] * 3
    for i in range(len(splitThemes)):
        finalThemes[i] = splitThemes[i]
    return finalThemes

# This takes in one row of parsed parameters of the Player table and inserts them into the SQL database
def insertResponse(cursor, s_id, q_id, response, theme1, theme2, theme3):
    Response_string = 'INSERT INTO Response (s_id, q_id, response, theme1, theme2, theme3) VALUES (%s, %s, %s, %s, %s, %s);'
    param1 = s_id
    param2 = q_id
    param3 = response
    param4 = theme1
    param5 = theme2
    param6 = theme3
    
    try:
        cursor.execute(Response_string, (param1, param2, param3, param4, param5, param6))
    except mysql.connector.Error as error_descriptor:
        print("Failed inserting tuple: {}".format(error_descriptor))
        # Do not exit program, continue
    pass

    s_id = cursor.lastrowid
    return s_id

def insertQuestion(cursor, q_id, q_text):
    Question_string = 'INSERT INTO Question VALUES (%s, %s);'

    param1 = q_id
    param2 = q_text
    
    try:
        cursor.execute(Question_string, (param1, param2))
    except mysql.connector.Error as error_descriptor:
        print("Failed inserting tuple: {}".format(error_descriptor))
        # Do not exit program, continue
    pass


def insertStudent(cursor, s_year, hall):
    Student_string = 'INSERT INTO Student (s_year, hall) VALUES (%s, %s);'
    #param1 = s_id
    param2 = s_year
    param3 = hall
    
    try:
        cursor.execute(Student_string, (param2, param3))
    except mysql.connector.Error as error_descriptor:
        print("Failed inserting tuple: {}".format(error_descriptor))
        # Do not exit program, continue
    pass

    s_id = cursor.lastrowid
    return s_id



# Read the 'QuestionSchema.sql' file into the 'schema_string' variable
# See 'QuestionSchema.sql' for comments on what that file should contain
sql_file = open("QuestionSchema.sql")
schema_string = sql_file.read()

# Connect to MySQL
connection = mysql.connector.connect(user='root', password='123456', host='localhost')
cursor = connection.cursor()

databaseName = "RLO"

# Run the contents of 'QuestionSchema.sql', creating a schema (deleting previous incarnations),
# and creating the relations mentioned in the handout.
try:
    result_iterator = cursor.execute(schema_string, multi=True)
    for r in result_iterator:
        pass
except mysql.connector.Error as error_descriptor:
    print("Failed creating schema: {}".format(error_descriptor))
    exit(1)

cursor.close()

cursor = connection.cursor()

# After running the contents of 'QuestionSchema.sql', we implement
# a USE RLO in our connection before adding the tuples.
try:
    cursor.execute("USE {}".format(databaseName))
except mysql.connector.Error as error_descriptor:
    print("Failed using database: {}".format(error_descriptor))
    exit(1)

col_22 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 14, 15, 16, 17,  None, None, None, None, None]
col_23 = [2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 22, 23, 24, 25, 26, 27, 28, 29, 30]
col_24 = [2, 3, 5, 6, 7, 8, 15, 16, 17, 18, 19, 27, 28, 29, 30, 31, 32, 33, 34, 35]


filenames = glob.glob("Co2[0-9]FYE.csv")
filenames.sort()

for filename in filenames:
    # reading the contents of the files into a pandas dataframe
    
    df = pd.read_csv(filename)
    year = (2020 + int(filename[3]))
    numpy_array = df.to_numpy(na_value=None)
    
    if year == 2022:
        for i in range(len(col_22)):
            if col_22[i] != None:
                insertQuestion(cursor, i, numpy_array[0][col_22[i]])
    
    if year == 2023:
        for i in range(15, len(col_23)):
            insertQuestion(cursor, i, numpy_array[0][col_23[i]])


    for i in range(1, numpy_array.shape[0]):
        responses = []
        if year == 2022:
            for j in range(len(col_22)):
                if col_22[j] != None:
                    responses.append(numpy_array[i][col_22[j]])
                else:
                    responses.append(None)
        
        elif year == 2023:
            for j in range(len(col_23)):
                if col_23[j] != None:
                    responses.append(numpy_array[i][col_23[j]])
                else:
                    responses.append(None)
            
        else:
            for j in range(len(col_24)):
                if col_24[j] != None:
                    responses.append(numpy_array[i][col_24[j]])
                else:
                    responses.append(None)
        
        s_id = insertStudent(cursor, year, responses[1])

        for i in range(len(responses)):
            if responses[i] != None:
                if (i > 4):
                    themeList = themeIdentifier(responses[i])
                else:
                    themeList = [None]*3
                insertResponse(cursor, s_id, i, responses[i], themeList[0], themeList[1], themeList[2])


connection.commit()
cursor.close()  
connection.close()

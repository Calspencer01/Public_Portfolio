custom_pie <- function(df_filtered, question_id){
  df <- df_filtered
  if (is.null(df)){
    e_title(e_chart(df), "No Data") %>%
    e_grid(top = "5%")
  }
  else {
    if (question_id == 4){
      df <- df %>%
        mutate(response = case_when(response == "5+" ~ "Every day"
                                    , response == "3-4 times" ~ "Often"
                                    , response == "1-2 times" ~ "Sometimes"
                                    , response == "Never" ~ "Rarely"))
    }
    df <- df %>%
      filter(q_id == question_id) %>%
      group_by(response) %>%
      tally()
    
    
    df %>%
      rename(Responses = n, Response = response) %>%
      e_chart(Response) %>%
      e_pie(Responses, label = c(show = F)) %>%
      e_legend(show = T, bottom = "3%", orient = "horizontal") %>%
      e_grid(top = "5%") %>%
      e_tooltip()
  }
}

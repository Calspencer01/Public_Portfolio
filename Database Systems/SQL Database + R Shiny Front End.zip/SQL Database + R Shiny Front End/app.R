#install.packages(c("shinydashboard", "echarts4r"))
library(shinydashboard)
library(shinyWidgets)
library(echarts4r)
library(tidyr)

source("data_intake.R", local = T)
source("utils.R", local = T)

ui <- 
  dashboardPage(
    
    skin = "red"
    , title = "First-Year Experience Data Dashboard"
    , dashboardHeader(
      title = "First-Year Experience Data Dashboard"
      , titleWidth = 400)
    , dashboardSidebar(disable = TRUE)
    , dashboardBody(
      
      fluidRow(
        column(width = 4,
          box(width = NULL
              , title = uiOutput("n_responses")
              , status = "danger"
              , uiOutput("class_filter")
              , uiOutput("dorm_filter")
              , uiOutput("question_filter")
          )
        )
        , column(width = 8
                 , box(width = 12
                       , title = "Key Themes Among Responses"
                       , status = "danger"
                       , p(
                         paste("The following key words are the most frequently written words among
                             student responses to a variety of survey questions."
                         )
                       )
                       , echarts4rOutput("keywords", height = "30vh")
                 ) 
          )
        # , column(width = 4
        #          , box(width = 12, status = "danger", 
        #                title = "Were you satisfied with your level of engagement with your RA?",
        #                echarts4rOutput("pct_RA_engagement", height = "30vh")
        #               )
        # )
        
      )
      
      , fluidRow(
        column(width = 3
               , box(width = 12
                     , title = "How many times a month did you have a one-on-one interaction with your Resident Advisor (RA)?"
                     , status = "danger"
                     , echarts4rOutput("ra_interaction", height = "30vh")
                     ))
        , column(width = 3
               , box(width = 12
                     , title = "Were you satisfied with your level of engagement with your RA?"
                     , status = "danger"
                     , echarts4rOutput("ra_engagement", height = "30vh")
                     ))
        , column(width = 3
                 , box(width = 12
                       , title = "How frequently did you engage with other residents on your floor?"
                       , status = "danger"
                       , echarts4rOutput("student_engagement", height = "30vh")
                       ))
        , column(width = 3
                  , box(width = 12
                        , title = "How many events did you attend in your residence hall (hosted by your RA or RLO)?"
                        , status = "danger"
                        , echarts4rOutput("event_engagement", height = "30vh")
                        ))
    )
  )
)

################################################################################

server <- 
  function(input, output, session) {
    df_filtered <- reactive({
      req(input$class)
      req(input$dorm)
      req(input$question)
      
      df_joined <- r$df_response %>%
        left_join(r$df_student, by = "s_id") %>%
        left_join(r$df_question, by = "q_id")
      
      df <- df_joined %>%
        filter(s_year %in% input$class) %>%
        filter(hall %in% input$dorm)
    })
    
    
    themes_filtered <- reactive({
      df_themes <- df_filtered() %>%
        filter(q_text %in% input$question) %>% 
        select(theme1, theme2, theme3) %>%
        unlist() %>%
        table() %>%
        t() %>%
        as.data.frame() %>%
        select(t_id = ".", responses = Freq) 
      
    })
    
    
    # Render UI Inputs ----
    output$class_filter <- renderUI({
      years <- unique(r$df_student$s_year)
      pickerInput(inputId = "class"
                  , label ="Filter by class year"
                  , selected = years
                  , choices = years
                  , multiple = T
                  , options = list(`selected-text-format`= "count", `actions-box` = TRUE)
      )
    })
    output$dorm_filter <- renderUI({
      dorms <- unique(r$df_student$hall)
      pickerInput(inputId = "dorm"
                  , label = "Filter by dormitory"
                  , selected = dorms
                  , choices = dorms
                  , multiple = T
                  , options = list(`selected-text-format`= "count", `actions-box` = TRUE)
      )
    })
    
    output$question_filter <- renderUI({
      questions <- unique(r$df_question$q_text[7:nrow(df_question)])
      pickerInput(inputId = "question"
                  , label = "Filter by question"
                  , selected = questions
                  , choices = questions
                  , multiple = T
                  , options = list(`selected-text-format`= "count", `actions-box` = TRUE)
      )
    })
    
    
    output$keywords <- renderEcharts4r({
      req(input$question)
      df <- themes_filtered()
      
      df_sorted <- df[order(-df$responses),][5:1,] %>%
        mutate(t_id = as.character(t_id)) %>%
        left_join(mutate(r$df_theme, t_id = as.character(t_id)), by = "t_id")
      
      df_sorted %>%
        e_chart(theme) %>%
        e_bar(responses) %>%
        e_flip_coords() %>%
        e_grid(left = "25%", bottom = "10%", top = "10%") %>%
        e_legend(show = FALSE)
    })
    
    output$n_responses <- renderUI({
      # req(r$df_student)
      # # ids <- filtered_student_ids()
      # 
      # total <- r$df_student %>%
      #   # filter(student_id %in% ids) %>%
      #   nrow()
      
      # div(class = "value_box_output"
      df <- df_filtered()
        
      if (!is.null(df)){
        df <- df %>%
          select(s_id) %>%
          unique()
        
        div(style = "text-align:center;"
            , paste0(nrow(df), " students polled"))
      } else {
        div(style = "text-align:center;"
            , paste0("0 students polled"))
      }
        
      
      
    })
    
    output$ra_interaction <- renderEcharts4r({
      custom_pie(df_filtered(), 2)
    })
    
    output$ra_engagement <- renderEcharts4r({
      custom_pie(df_filtered(), 3)
    })
    
    output$student_engagement <- renderEcharts4r({
      custom_pie(df_filtered(), 4)
    })
    
    output$event_engagement <- renderEcharts4r({
      custom_pie(df_filtered(), 5)
    })
    
  }

################################################################################

shinyApp(ui = ui, server = server)